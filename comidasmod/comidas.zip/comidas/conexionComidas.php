<?php
$bd="comidasadomicilio";
$user="eavila";
$password="emildaniel";
$server="localhost";
?>