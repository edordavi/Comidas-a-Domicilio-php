<?php

echo <<<HTML
<!-- Footer -->
    </div>
</div>
<div class="wrapper row4">
  <footer id="footer" class="clear">
    <p class="fl_right">Estilo por: <a href="http://www.os-templates.com/" title="Free Website Templates">OS Templates</a></p>
  </footer>
</div>
</body>
</html>
HTML;
?>
