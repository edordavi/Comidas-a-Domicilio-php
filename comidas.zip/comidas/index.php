

<?php
session_start();
$titulo='Comidas Inicio';
include "encabezado.php";


include "pie.php"
?>